package com.example.JuntadaAmigos.Service;

import com.example.JuntadaAmigos.Models.Amigo;
import com.example.JuntadaAmigos.Models.Reunion;
import com.example.JuntadaAmigos.Repository.AmigoRepository;
import com.example.JuntadaAmigos.Repository.ReunionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReunionService {

    @Autowired
    private ReunionRepository ReunionRepository;

    public Reunion create(Reunion newReunion) {
        return this.ReunionRepository.save(newReunion);
    }

    public List<Reunion> findAll() {
        return this.ReunionRepository.findAll();
    }

    public Reunion update(Reunion reunion, Integer id) {
        Optional<Reunion> reunionBD = this.ReunionRepository.findById(id);
        if (reunionBD.isPresent()) {
            Reunion r = reunionBD.get();
            r.setFecha(reunion.getFecha());
            r.setDescripcion(reunion.getDescripcion());
            r.setLugar(reunion.getLugar());
            r.setParticipantes(reunion.getParticipantes());
            return this.ReunionRepository.save(r);
        } else {
            return null;
        }
    }

    public void delete(Integer id) {
        this.ReunionRepository.deleteById(id);

    }
}
