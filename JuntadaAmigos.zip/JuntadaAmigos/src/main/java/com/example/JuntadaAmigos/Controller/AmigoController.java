package com.example.JuntadaAmigos.Controller;

import com.example.JuntadaAmigos.Models.Amigo;
import com.example.JuntadaAmigos.Service.AmigoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping(path = "api/JuntadaAmigos")
@RestController
public class AmigoController {

    @Autowired
    private AmigoService AmigoService;

    @PostMapping("/")
    public ResponseEntity<Amigo> create(@RequestBody Amigo amigo) {
        return new ResponseEntity<>(this.AmigoService.create(amigo), HttpStatus.OK);

    }

    @GetMapping("/")
    public ResponseEntity<List<Amigo>> findAll() {
        return new ResponseEntity<>(this.AmigoService.findAll(), HttpStatus.OK);

    }


}
