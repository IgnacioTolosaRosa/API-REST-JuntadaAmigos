package com.example.JuntadaAmigos.Controller;

import com.example.JuntadaAmigos.Models.Amigo;
import com.example.JuntadaAmigos.Models.Reunion;
import com.example.JuntadaAmigos.Service.AmigoService;
import com.example.JuntadaAmigos.Service.ReunionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping(path = "api/JuntadaAmigos/reunion")
@RestController
public class ReunionController {

    @Autowired
    private ReunionService ReunionService;

    @PostMapping("/")
    public ResponseEntity<Reunion> create(@RequestBody Reunion reunion) {
        return new ResponseEntity<>(this.ReunionService.create(reunion), HttpStatus.OK);

    }

    @GetMapping("/")
    public ResponseEntity<List<Reunion>> findAll() {
        return new ResponseEntity<>(this.ReunionService.findAll(), HttpStatus.OK);

    }
}
