package com.example.JuntadaAmigos.Repository;

import com.example.JuntadaAmigos.Models.Amigo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AmigoRepository extends JpaRepository<Amigo,Integer> {
}
