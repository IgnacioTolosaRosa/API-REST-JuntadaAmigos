package com.example.JuntadaAmigos.Models;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "amigo")
public class Amigo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
