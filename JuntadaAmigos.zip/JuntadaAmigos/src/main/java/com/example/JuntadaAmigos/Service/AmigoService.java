package com.example.JuntadaAmigos.Service;

import com.example.JuntadaAmigos.Models.Amigo;
import com.example.JuntadaAmigos.Repository.AmigoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AmigoService {

    @Autowired
    private AmigoRepository AmigoRepository;

    public Amigo create(Amigo newAmigo) {
        return this.AmigoRepository.save(newAmigo);
    }

    public List<Amigo> findAll() {
        return this.AmigoRepository.findAll();
    }

    public Amigo update(Amigo amigo, Integer id) {
        Optional<Amigo> amigoBD = this.AmigoRepository.findById(id);
        if (amigoBD.isPresent()) {
            Amigo a = amigoBD.get();
            a.setNombre(amigo.getNombre());
            return this.AmigoRepository.save(a);
        } else {
            return null;
        }
    }

    public void delete(Integer id) {
        this.AmigoRepository.deleteById(id);

    }
}
