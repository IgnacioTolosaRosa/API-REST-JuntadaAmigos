package com.example.JuntadaAmigos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuntadaAmigosApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuntadaAmigosApplication.class, args);
	}

}
