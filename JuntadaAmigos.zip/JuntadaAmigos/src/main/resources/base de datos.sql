create database juntada;
use juntada;
create table Amigo(
id integer not null primary key auto_increment,
 nombre varchar(30)
);
create table Reunion(
id integer not null primary key auto_increment,
fecha varchar(20) ,
descripcion varchar(200) ,
lugar varchar(100),
participantes varchar(300),
Amigo_id int,
constraint fk_Amigo_id foreign key(Amigo_id) references Amigo(id)
);