package com.example.JuntadaAmigos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuntadaAmigosApplicationTests {

	@Test
	void contextLoads() {
	}

}
